import { RegistrationService } from './../service/registration.service';
import {  Router } from '@angular/router';
import { User } from './../service/user';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  user =new User();
  msg='';

  constructor(private _service:RegistrationService, private _router: Router) { }

  ngOnInit(): void {
  }
  registeruser(){
    this._service.registerUserFromRemote(this.user).subscribe(
      data => {console.log("respone recieved");
      this._router.navigate(['login']);
  
    },
    _error => {console.log("exception occured");
    this.msg="Bad credential, please enter valid Email and Password";
   
  
    }
    );
  }
  

}

