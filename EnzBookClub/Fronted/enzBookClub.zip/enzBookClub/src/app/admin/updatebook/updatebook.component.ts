import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminServiceService } from 'src/app/service/admin-service.service';
import { Book } from 'src/app/service/book';


@Component({
  selector: 'app-updatebook',
  templateUrl: './updatebook.component.html',
  styleUrls: ['./updatebook.component.css']
})
export class UpdatebookComponent implements OnInit {

  bid: number;
  book: Book = new Book();
  constructor(private updateService: AdminServiceService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.bid = this.route.snapshot.params['bid'];

    this.updateService.getBookById(this.bid).subscribe(data => {
      this.book = data;
    }, error => console.log(error));
  }

  onSubmit(){
    this.updateService.updateBook(this.bid, this.book).subscribe( data =>{
      this.getBook();
    }
    , error => console.log(error));
  }
  
  getBook(){
    this.router.navigate(['/admin/view-book']);
  }
}

