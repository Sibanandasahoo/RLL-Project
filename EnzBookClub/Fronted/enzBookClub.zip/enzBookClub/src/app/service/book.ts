

export class Book{
  bid:number;
  bname:string; 
  bprice:number; 
  bseller:string;
  bauthor:string;
  bdescp:string;
  image:string;

}
