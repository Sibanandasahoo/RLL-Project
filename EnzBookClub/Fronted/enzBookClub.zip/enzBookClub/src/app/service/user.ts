export class User {
    id: number;
    emailId: string;
    userName: string;
    password: string;
    cpassword:string;
   
    constructor(){}
  
}


