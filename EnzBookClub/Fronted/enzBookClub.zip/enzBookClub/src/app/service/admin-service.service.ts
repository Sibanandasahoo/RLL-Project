import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Book } from './book';
import { Feedback } from './feedback';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

  constructor(private httpClient: HttpClient) { }

  public addToDb(book :Book):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/api/v1/addBooks",book)
  }

  updateBook(bid: number, book: Book): Observable<object>{
    return this.httpClient.put("http://localhost:8080/api/v1/update/", book);
  }

  public getbooks(){
    return this.httpClient.get("http://localhost:8080/api/v1/vbooks")
  }

  public deleteUser(id:any){
    return this.httpClient.delete("http://localhost:8080/api/v1/cancel/"+id);
  }
  
  getBookById(bid: number): Observable<Book>{
    return this.httpClient.get<Book>("http://localhost:8080/api/v1/books/"+bid);
  }
  
  feedBack(feedback:Feedback):Observable<Feedback>{
    return this.httpClient.get<Feedback>("http://localhost:8080/api/v1/feedback/list");
  }
}
