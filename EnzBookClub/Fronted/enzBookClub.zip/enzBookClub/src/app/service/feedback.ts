export class Feedback {
     fid:number;
	 review: string
	rating: string;
	 bid: number;
	  id: number;
   
    constructor(){}
}
