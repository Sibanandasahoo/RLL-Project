import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Feedback } from './feedback';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient: HttpClient) { }

  public addToDb(feedback :Feedback):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/api/v1/feedback/insert",feedback)
  }

  getUserById(id: number): Observable<User>{
    return this.httpClient.get<User>("http://localhost:8080/user/"+id);
  }
}
