import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from './../../service/book';
import { AdminServiceService } from 'src/app/service/admin-service.service';


@Component({
  selector: 'app-showbooks',
  templateUrl: './showbooks.component.html',
  styleUrls: ['./showbooks.component.css']
})
export class ShowbooksComponent implements OnInit {

  constructor(private Service:AdminServiceService, private router:Router) { }
  books:any
public deleteUser(bid:number){
let resp=this.Service.deleteUser(bid);
resp.subscribe((data)=>this.books=data);

}
  ngOnInit(): void {

    let resp =this.Service.getbooks();
    resp.subscribe((data)=>this.books =data);
  }
  userdashboard(){
    this.router.navigate(['/loginsuccess'])
  }
  
}


