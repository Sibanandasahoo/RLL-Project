import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';

import { AddbookComponent } from './admin/addbook/addbook.component';
import { ViewBookComponent } from './admin/view-book/view-book.component';
import { AdminsuccessComponent } from './admin/adminsuccess/adminsuccess.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { UpdatebookComponent } from './admin/updatebook/updatebook.component';
import { ShowbooksComponent } from './loginsuccess/showbooks/showbooks.component';
import { ViewfeedbackComponent } from './admin/viewfeedback/viewfeedback.component';
import { UserfeedbackComponent } from './userfeedback/userfeedback.component';
import { UserprofileComponent } from './loginsuccess/userprofile/userprofile.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    HomeComponent,
    LoginsuccessComponent,
    AdminComponent,
    AdminsuccessComponent,
   AddbookComponent,
   ViewBookComponent,
   UpdatebookComponent,
   ShowbooksComponent,
   ViewfeedbackComponent,
   UserfeedbackComponent,
   UserprofileComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
