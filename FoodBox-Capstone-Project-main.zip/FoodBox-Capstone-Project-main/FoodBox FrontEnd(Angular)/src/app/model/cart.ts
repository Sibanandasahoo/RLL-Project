import { Product } from "./product";
export class Cart{
    id:number;
    quantity:number;
    price:number;
    product:Product;
}